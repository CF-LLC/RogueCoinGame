import InvoiceGeneratorApp from "@/components/invoice-generator-app"

export default function Home() {
  return (
    <main>
      <InvoiceGeneratorApp />
    </main>
  )
}

